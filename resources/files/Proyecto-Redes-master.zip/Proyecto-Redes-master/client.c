#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>

void error(const char *);

void *ack_thread(void *param);

void fill_window_sequence();

void fill_retransmition();

void modify_arrays();

pthread_mutex_t mutex;
pthread_mutex_t mutex_size;
int sock;
struct sockaddr_in server;
unsigned int length;
float *ventana;
int window_size = 10;
const int SEQUENCE = 0;
const int ACK = 1;
const int WINDOW = 2;
int ack = -1;
bool is_retransmition = false;
bool rcv = true;
int *retransmition;

int main(int argc, char *argv[])
{
	ventana = (float *)malloc(32*10*sizeof(float));
	fill_window_sequence();
	
	retransmition = (int *)malloc(10*sizeof(int));
	fill_retransmition();
				
	int n;
   	struct sockaddr_in from;
  	struct hostent *hp;  
   	if (argc != 2) { 
   		printf("Usage: server port\n");
        	exit(1);
   	}
   	sock= socket(AF_INET, SOCK_DGRAM, 0);
   	if (sock < 0) error("socket");
   	server.sin_family = AF_INET;
   	hp = gethostbyname(argv[1]);
   	if (hp==0) error("Unknown host");
   	bcopy((char *)hp->h_addr, 
        (char *)&server.sin_addr,
         hp->h_length);
   	server.sin_port = htons(8080);
   	length=sizeof(struct sockaddr_in);
   	
   	pthread_mutex_lock(&mutex);
   	ventana[SEQUENCE] = -1;
   	ventana[ACK] = 0;
   	ventana[WINDOW] = 10;
    pthread_mutex_unlock(&mutex);
    
	n = sendto(sock,ventana,128,0,(const struct sockaddr *)&server,length);
    
    pthread_attr_t attr;
    pthread_t tid;
	int *ret;
	float packet[32];
	
	int mensajesRecibidos = 0;
	
    pthread_attr_init(&attr);
    pthread_create(&tid, &attr, ack_thread, NULL);
   	
   	bool requested = true;
   	
   	while(true) {
		if (n < 0) error("Sendto");
   
		printf("------------VENTANA NUEVA-----------\n");
		pthread_mutex_lock(&mutex_size);
		while(mensajesRecibidos < window_size) {
			
			if(requested) {
				requested = false;
				pthread_mutex_unlock(&mutex_size);
			}
			
			if(rcv) {
				n = recvfrom(sock, packet,128,0,(struct sockaddr *)&from, &length);
				printf("----------------------------------------------------------\n");
				printf("Se recibió un paquete con número de secuencia %f\n",packet[SEQUENCE]);
				
				if(ventana[((int)packet[SEQUENCE] * 32) + SEQUENCE] == -1) {
					++mensajesRecibidos;
					printf("MENSAJE RECIBIDOS: %i\n", mensajesRecibidos);
				}

				if (n < 0)
				{
					error("recvfrom");
				}
			
				pthread_mutex_lock(&mutex);
				if(ack == packet[SEQUENCE] && ack != -1) {
					++retransmition[(int)packet[SEQUENCE]];
					printf("El paquete %.0f ha llegado %i vez.\n", packet[SEQUENCE], retransmition[(int)packet[SEQUENCE]]);
				}
			
				ventana[((int)packet[SEQUENCE] * 32) + SEQUENCE] = packet[SEQUENCE];
				ventana[((int)packet[SEQUENCE] * 32) + ACK] = packet[ACK];
				ventana[((int)packet[SEQUENCE] * 32) + WINDOW] = packet[WINDOW];
				pthread_mutex_unlock(&mutex);
		
				for(int i = 0; i < window_size; ++i) {
					printf("%.2f ", ventana[i * 32]);
				}
				printf("\n");
				printf("----------------------------------------------------------\n\n");
			}
			
			if(!requested) {
				requested = true;
				pthread_mutex_lock(&mutex_size);
			}
		}
		
		if(is_retransmition){
			is_retransmition = false;
			window_size /= 2;
			printf("Tamaño de ventana nuevo (reduccion): %i.\n", window_size);
			modify_arrays();
			fill_retransmition();
			fill_window_sequence();
			ack = -1;
		} else {
			window_size += 1;
			printf("Tamaño de ventana nuevo (aumento): %i.\n", window_size);
			modify_arrays();
			fill_retransmition();
			fill_window_sequence();
			ack = -1;
		}
		
		fill_window_sequence();
		
		pthread_mutex_unlock(&mutex_size);
		mensajesRecibidos = 0;
	}
	
   	return 0;
}

void error(const char *msg)
{
    perror(msg);
    exit(0);
}

void *ack_thread(void *param) {
	int n;
	int cont = 0;
	float packet[32];
	bool set = false;
	bool requested = true;
	
	while (true) {
		sleep(5);
		
		pthread_mutex_lock(&mutex);
		
		
		if(ack != -1) { //Si no está duplicado es porque sí se perdió el paquete
			if(retransmition[ack] != 2 ){
				printf("Es una retransmisión del paquete %i.\n", ack);
				is_retransmition = true;
				retransmition[ack] = 0; //Lo reinicia.
			} else {
				retransmition[ack] = 0; //Lo reinicia.
			}
		}
		
		while(cont < window_size && !set){ //Revisa todos los campos, donde encuentre un -1 ahi va ack.
			if(!requested) {
				requested = true;
				pthread_mutex_lock(&mutex);
			}
			
			if(ventana[(cont * 32) + SEQUENCE] == -1) {
				packet[SEQUENCE] = -1;
				packet[ACK] = cont;
				packet[WINDOW] = window_size;		
				ack = cont; //Setea el ack
				printf("ACK es: %i\n", ack);
				printf("ACK del paquete es: %f\n", packet[ACK]);
				printf("La ventana es: %f \n\n",packet[WINDOW]);
				n = sendto(sock,packet,128,0,(const struct sockaddr *)&server,length);
			
				if (n < 0)
				{
					error("sendto");
				}
				
				set = true;
			}
			
			if(requested) {
				requested = false;
				pthread_mutex_unlock(&mutex);
			}
		
			cont++;
		}
		
		/*pthread_mutex_lock(&mutex);
		if(cont == window_size){
			packet[ACK] = cont;
			ack = cont;
			printf("ACK final es: %i\n", ack);
		}
		pthread_mutex_unlock(&mutex);*/
		
		cont = 0;
		set = false;
		requested = true;
	}
}

void modify_arrays(){
	if(window_size != 0 && window_size > 10) {
		free(ventana);
		free(retransmition);
		printf("Modificar ventana y retransmision con tamaño %i.\n", window_size);
		ventana = (float*)malloc(sizeof(float) * 32 * window_size);
		retransmition = (int*)malloc(sizeof(int) * window_size);
	} else if(window_size == 0){
		rcv = false;
	}
}

void fill_window_sequence() {
	for(int i = 0; i < 10; ++i) {
		ventana[(i * 32) + SEQUENCE] = -1;
	}
}

void fill_retransmition() {
	for(int i = 0; i < 10; ++i) {
		retransmition[i] = 0;
	}
}
