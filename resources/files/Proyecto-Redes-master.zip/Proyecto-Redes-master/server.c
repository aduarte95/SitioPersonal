#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdbool.h>
#include <time.h>

int contador;
pthread_mutex_t mutex;
float rtt_actual=7.0;
float alpha = 0.5;
float beta = 2.0;
clock_t inicia;
clock_t finaliza;
float timeout = 14.0;
bool ventanaEnviada = false;

void error(const char *msg)
{
    perror(msg);
    exit(0);
}

void rellenarVentana(float *ventana, int tamano)
{
	int limite = 32*tamano;
	for(int x = 0; x < limite; x++)
	{
		ventana[x] = 0.0;
	}
}

void ingresarSecuencias(float *ventana,int tamano)
{
	for(int x = 0; x < tamano; x++)
	{
		ventana[x*32] = (float)x;
	}
}



void printMatrix(float *ventana,int tamano)
{
	int limite = tamano*32;
	for(int posicion = 0; posicion < limite; posicion ++)
	{
		if(posicion % 32 == 0)
		{
			printf("\nPaquete número %d \n",posicion/32);
		}
		printf("%.1f ", ventana[posicion]);
		if(posicion % 32 == 0 )
		{
			printf("\n");
		}
	}
	printf("\n");
}

void modificar(float *ventana[],int tamano)
{
	free(*ventana);
	*ventana = (float*)malloc(sizeof(float) * 32 * tamano);
}

void calcular_rtt(float rtt_calculado){
	rtt_actual = (alpha * rtt_actual) + ((1 - alpha) * rtt_calculado);
}

void calcular_timeout(){
	timeout = beta * rtt_actual;
}

int main(int argc, char *argv[])
{
   	int sock, length, n;
   	socklen_t fromlen;
   	struct sockaddr_in server;
  	struct sockaddr_in from;
   	float *buf = (float *)malloc(32*sizeof(float));;
   	float *ventana =(float *)malloc(32*10*sizeof(float));
   	rellenarVentana(ventana,10);
   	ingresarSecuencias(ventana,10);
   	//printMatrix(ventana, 10);
   	//sleep(100);
	float paquete[32];
   	sock=socket(AF_INET, SOCK_DGRAM, 0);
   	if (sock < 0) error("Opening socket");
   	length = sizeof(server);
   	bzero(&server,length);
   	server.sin_family=AF_INET;
   	server.sin_addr.s_addr=INADDR_ANY;
   	server.sin_port=htons(8080);
   	if (bind(sock,(struct sockaddr *)&server,length)<0) 
       	error("binding");
   	fromlen = sizeof(struct sockaddr_in);

	srand(time(NULL));
	n = recvfrom(sock,buf,128,0,(struct sockaddr *)&from,&fromlen);
	int tamanoVentana =(int) buf[2];
	printf("La ventana  es : %d \n",tamanoVentana);
     if (n < 0)
     {
          printf("\nAquí\n");     	
     	//error("recvfrom");
     }
     else
     {  
		bool pedido = false;
     	int nuevoTamano =tamanoVentana ;
	float ack = 0.0;
     	while(true)
     	{
		    	
			if(nuevoTamano != tamanoVentana)
			{
				modificar(&ventana,nuevoTamano);
   				rellenarVentana(ventana,nuevoTamano);
   				ingresarSecuencias(ventana,nuevoTamano);
				tamanoVentana = nuevoTamano;
			}
			pthread_mutex_lock(&mutex);
			contador = 0;
		 	pedido = true;
		 	printf("------------VENTANA NUEVA-----------\n");
			while (contador < tamanoVentana)
			{
				if(!pedido) {
					pthread_mutex_lock(&mutex);
				}
				
				if(recvfrom(sock,buf,128,MSG_DONTWAIT,(struct sockaddr *)&from,&fromlen) != -1)
				{
					if(buf[0] == -1){
						printf("\nRecibí un ack con número de secuencia: %f\n\n", buf[1]);
						ack = buf[1];

					}
					//contador = (int)buf[1] % tamanoVentana;
					if((int)buf[2] != tamanoVentana)
					{
						printf("El nuevo tamaño de ventana es %f",buf[2]);
						nuevoTamano = (int)buf[2];
					}
					if( (buf[0] <= contador ) == 0)
					{
						printf("Se va a retransmitir a partir de: %f\n",buf[0]);
						contador = buf[0];
					}
					float tiempoEnQueInicio =  buf[4];
					finaliza = clock();
					float tiempoEnQueTermino = (float) finaliza;
					float rttCalculado = (tiempoEnQueTermino - tiempoEnQueInicio) / 10000;
					calcular_rtt(rttCalculado);
					printf("*****************RTT ES: %f******************\n", rtt_actual);
					calcular_timeout();
				}
				sleep(drand48() * (1-0.5) + 1);
				inicia=clock();
				float tiempoInicio = (float) inicia;
				ventana[contador+3] = tiempoInicio; // pone en 4ta posicion el tiempo en el que inicio
				
				
				
	   			if(rand()%101 <= 80)
	   			{
					printf("***************** Numero de secuencia es: %f******************\n", ventana[contador*32]);
		  			n = sendto(sock,&ventana[contador*32],128,MSG_DONTWAIT,(struct sockaddr *)&from,fromlen);
		  		}
		  		else
		  		{
		  			printf("\nEl paquete %d se perdió en el camino.\n\n",contador);
		  		}
				     
		  		//n = sendto(sock,&ventana[contador*32],128,MSG_DONTWAIT,(struct sockaddr *)&from,fromlen);            	
		  		if (n  < 0)
		  		{
		  			 error("sendto");
		  		}
		  		contador++;
		  		
		  		if(pedido) {
					pedido = false;
				}
				pthread_mutex_unlock(&mutex);
      		}
		
      		//pthread_mutex_unlock(&mutex);
      	}
   	}
   	return 0;
 }
