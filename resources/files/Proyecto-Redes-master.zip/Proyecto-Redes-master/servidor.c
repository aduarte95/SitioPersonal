#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include <time.h>

void error(const char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
   	int sock, length, n;
   	socklen_t fromlen;
   	struct sockaddr_in server;
  	struct sockaddr_in from;
   	int buf[32];
	int paquete[32];
   	sock=socket(AF_INET, SOCK_DGRAM, 0);
   	if (sock < 0) error("Opening socket");
   	length = sizeof(server);
   	bzero(&server,length);
   	server.sin_family=AF_INET;
   	server.sin_addr.s_addr=INADDR_ANY;
   	server.sin_port=htons(8080);
   	if (bind(sock,(struct sockaddr *)&server,length)<0) 
       	error("binding");
   	fromlen = sizeof(struct sockaddr_in);

	srand(time(NULL));
	n = recvfrom(sock,buf,1024,0,(struct sockaddr *)&from,&fromlen);
       	if (n < 0)
       	{
       		error("recvfrom");
       	}
       	else
       	{  
       		int tamanoVentana = buf[2];
       		printf("El tamaño de la ventana es %d\n",tamanoVentana);
       		int contador = 0;
		while (contador < tamanoVentana) 
		{
			
			sleep(drand48() * (1-0.5) + 1);
			paquete[0] = contador;
   			paquete[1] = 1;
   			paquete[2] = tamanoVentana;
   			if(rand()%101 <= 80)
   			{   			
       				n = sendto(sock,paquete,128,0,(struct sockaddr *)&from,fromlen);
       			}
       			else
       			{
       				printf("El paquete %d se perdió en el camino.\n",contador);
       			}                  	
       			if (n  < 0)
       			{
       				 error("sendto");
       			}
       			contador++;
      		}
   	}
   	return 0;
}
