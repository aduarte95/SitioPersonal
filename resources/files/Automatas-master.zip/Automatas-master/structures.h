#include <string>
#include <iostream>
#include <sstream>

enum class VarNodeType{Variable, Array, Type};
enum class MethodNodeType{Declaration, Assignation, Method_call, Print, Input, If, While, For, Return};
enum class ValueType{Boolean, Operation, Char, String, Input};
enum class OperationType{Sum, Sub, Multiplication, Division, Module, Terminal};
enum class TerminalOperationType{Cast, Method_call, Array, Variable, Int, Float};
enum class ConditionType{AND, OR, EQ, NEQ, LESS, LESSEQ, GREATER, GREATEQ, Terminal};
enum class SymbolType{Variable, Method};

/********** Abstract syntax tree **********/

/**
 * Variable declaration tree node.
 * @class Var_node
 */

class Var_node{
public:
	virtual ~Var_node();
	virtual VarNodeType getVarNodeType() =0;
	virtual void print() =0;
};

/**
 * @class Variable
 */

class Variable : public Var_node{
public:
	std::string identifier;
	Variable* next;

	Variable(std::string newIdentifier);
	virtual ~Variable();

	void addNext(Variable* newNext);
	virtual VarNodeType getVarNodeType();
	virtual void print();
};

/**
 * @class Array
 */

class Assignation;
class Array : public Variable{
public:
	std::string size;

	Array(std::string newIdentifier, std::string newSize);
	~Array();

	VarNodeType getVarNodeType();
	void print();
	std::string getSize();
	std::string getIdentifier();
};

/**
 * Method declaration tree node.
 * @class Method_node
 */

class Method_node{
public:
	virtual ~Method_node();
	virtual void print(int tabs) =0;
};

/**
 * @class Instruction.
 */

class Instruction : public Method_node{
public:
	Instruction* next;

	virtual void addNext(Instruction * newNext);
	virtual int getInt(std::string operation);
	virtual MethodNodeType getMethodNodeType() =0;
};

/**
 * Parameters declaration list.
 * @class Param_dec
 */

class Param_dec{
public:
	std::string type;
	std::string value;
	Param_dec* next;

	Param_dec(std::string type, std::string value);
	~Param_dec();

	void print();
};

/**
 * @class Method
 */
class Table;
class Method : public Method_node{
public:
	std::string type;
	std::string identifier;
	Param_dec* parameter;
	Instruction* instruction;
	Method* next;

	Method(std::string newType, std::string newIdentifier);
	~Method();

	void enter_scope(Table* global);
	void addInstruction(Instruction* newInstruction);
	void addParam(Param_dec* newParameter);
	void print(int tabs);
};

/**
 * Variable declaration.
 * @class Type
 */

class Type : public Var_node, public Instruction{
public:
	std::string type;
	Variable* child;

	Type(std::string newType);
	~Type();

	void addVariable(Variable* newChild);
	std::string getType();
	VarNodeType getVarNodeType();
	MethodNodeType getMethodNodeType();
	void print();
	void print(int tabs);
};

/**
 * @class Operation
 */

class Operation{ // : public Value
public:
	Operation* lOperation;
	Operation* rOperation;
	// OperationType operationType;

	virtual ~Operation() =0;

	void addLeftOperation(Operation* newLOperation);
	void addRightOperation(Operation* newROperation);
	void print();
	virtual std::string getOperation() =0;
	virtual OperationType getOperationType() =0;
};

// Nueva implementación
/**
 * @class ArithmeticOperation
 */

// class ArithmeticOperation : public Operation{
// public:
// 	Operation* lOperation;
// 	Operation* rOperation;
//
// 	ArithmeticOperation(OperationType newOperationType, Operation* newLOperation, Operation* newROperation);
// 	~ArithmeticOperation();
//
// 	void addLeftOperation(Operation* newLOperation);
// 	void addRightOperation(Operation* newROperation);
//
// 	void print();
// 	std::string getOperation();
// 	OperationType getOperationType();
// };

class SumOperation : public Operation{
public:
	Operation* lOperation;
	Operation* rOperation;

	SumOperation(Operation* newLOperation, Operation* newROperation);
	~SumOperation();

	std::string getOperation();
	OperationType getOperationType();
};

class SubOperation : public Operation{
public:
	Operation* lOperation;
	Operation* rOperation;

	SubOperation(Operation* newLOperation, Operation* newROperation);
	~SubOperation();

	std::string getOperation();
	OperationType getOperationType();
};

class MultOperation : public Operation{
public:
	Operation* lOperation;
	Operation* rOperation;

	MultOperation(Operation* newLOperation, Operation* newROperation);
	~MultOperation();

	std::string getOperation();
	OperationType getOperationType();
};

class DivOperation : public Operation{
public:
	Operation* lOperation;
	Operation* rOperation;

	DivOperation(Operation* newLOperation, Operation* newROperation);
	~DivOperation();

	std::string getOperation();
	OperationType getOperationType();
};

/**
 * @class OperationTerminal
 */

// Nueva implementación

class OperationTerminal : public Operation{
public:
 	TerminalOperationType operationTerminalType;

 	OperationTerminal();
 	~OperationTerminal();

 	virtual void print() =0;
	std::string getOperation();
 	OperationType getOperationType();
 	virtual TerminalOperationType getOperationTerminalType();
};

class SimpleOperationTerminal : public OperationTerminal{
public:
 	std::string value;

 	SimpleOperationTerminal(TerminalOperationType newOperationTerminalType, std::string newValue);
 	~SimpleOperationTerminal();

 	void print();
 	std::string getOperation();
 	OperationType getOperationType();

};

class Method_call;
 class MethodCallOperationTerminal : public OperationTerminal{
 public:
 	Method_call* method_call;

 	MethodCallOperationTerminal(TerminalOperationType newOperationTerminalType, Method_call* newMethod_call);
 	~MethodCallOperationTerminal();

 	void print();
 	std::string getOperation();
 	OperationType getOperationType();
 };

class Cast;
 class CastOperationTerminal : public OperationTerminal{
 public:
 	Cast* cast;

 	CastOperationTerminal(TerminalOperationType newOperationTerminalType, Cast* newCast);
 	~CastOperationTerminal();

 	void print();
 	std::string getOperation();
 	OperationType getOperationType();
 };

/**
 * @class assignation
 */

class Assignation : public Instruction{
public:
	std::string left_side;
	std::string assign_operator;
	std::string right_side;
	// Value* right_side; // TODO

	Assignation(std::string newLeft_side, std::string newAssignOperator, std::string newRightSide);
	~Assignation();

	MethodNodeType getMethodNodeType();
	std::string instructionToString();
	void print(int tabs);
};

/**
 * Method call's parameters list.
 * @class Param_dec
 */

class Parameter{
public:
	std::string value;
	Parameter* next;

	Parameter(std::string newValue);
	~Parameter();

	void addNext(Parameter* newNext);
	std::string getValue();
	void print(int tabs);
};

/**
 * @class Method_call
 */

class Method_call : public Instruction{
public:
	std::string identifier;
	Parameter* child;

	Method_call(std::string newIdentifier);
	~Method_call();

	void addParameter(Parameter* newChild);
	MethodNodeType getMethodNodeType();
	std::string instructionToString();
	void print(int tabs);
};

/**
 * @class Cast
 */

class InputValue;
class Cast{
public:
	std::string type;
	InputValue* input;

	Cast(std::string newType, InputValue* input);
	~Cast();

	std::string instructionToString();
	void print();
};

/**
 * String concatenation.
 * @class Concat
 */

class Concat{
public:
	std::string stringMsg;
	Concat* next;

	Concat(std::string stringMsg);
	~Concat();

	void addNext(Concat * newNext);
	std::string getConcatMsg();
	void print();
};

/**
 * @class Print
 */

class Print : public Instruction{
public:
	Concat* child;

	Print();
	~Print();

	void addConcatenation(Concat* newChild);
	MethodNodeType getMethodNodeType();
	void print(int tabs);
};

/**
 * @class Input
 */

class Input : public Instruction{
public:
	std::string message;

	Input(std::string newMessage);
	~Input();

	MethodNodeType getMethodNodeType();
	std::string instructionToString();
	void print(int tabs);
};

/**
 * @class Value
 */

class Value{
public:
	ValueType valueType;

	Value(ValueType newValueType);
	~Value();

	virtual ValueType getValueType() =0;
	virtual void print() =0;
};

/**
 * @class SimpleValue
 */

class SimpleValue : public Value{
public:
	std::string value;

	SimpleValue(ValueType newValueType, std::string newValue);
	~SimpleValue();

	ValueType getValueType();
	void print();
};

/**
 * @class OperationValue
 */

class OperationValue : public Value{
public:
	Operation* operation;

	OperationValue(ValueType valueType, Operation* NewOperation);
	~OperationValue();

	ValueType getValueType();
	void print();
};

/**
 * @class InputValue
 */

class InputValue : public Value{
public:
	Input* input;

	InputValue(ValueType newValueType, Input* newInput);
	~InputValue();

	ValueType getValueType();
	void print();
};

/**
 * @class Condition
 */

class Condition{
public:
	// Condition* lCondition;
	// Condition* rCondition;
	ConditionType conditionType;

	virtual ~Condition();

	// virtual void addLeftCondition(Condition* newLCondition) =0;
	// virtual void addRightCondition(Condition* newRCondition) =0;
	virtual void print() =0;
	virtual std::string getTerminal() =0; // Esto qué hace?
	ConditionType getConditionType();
};

/**
 * @class ConditionConcat
 */

class ConditionConcat : public Condition{
public:
	Condition* lCondition;
	Condition* rCondition;

	ConditionConcat(ConditionType newConditionType);
	~ConditionConcat();

	ConditionType getOperationType();
	void addLeftCondition(Condition* newLCondition);
	void addRightCondition(Condition* newRCondition);
	void print();
	std::string getTerminal();
};

/**
 * @class ComparisonCondition
 */

class ComparisonCondition : public Condition{
public:
	Condition* lCondition;
	Condition* rCondition;
	ConditionType conditionType;
	bool isNegated;

	ComparisonCondition(ConditionType newConditionType, bool isNegatedP);
	~ComparisonCondition();

	ConditionType getConditionType();
	void addLeftCondition(Condition* newLCondition);
	void addRightCondition(Condition* newRCondition);
	void print();
	std::string getTerminal();
};

/**
 * @class TerminalCondition
 */
// TODO arreglar para booleanos

class TerminalCondition : public Condition{
public:
	Operation* operation;

	TerminalCondition(Operation* newOperation);
	ConditionType getOperationType();

	void print();
	std::string getTerminal();
};

/**
 * @class Control_structure
 */

class Control_structure {
	public:
		virtual void enter_scope(Table* global) =0;
		void exit_scope(); // TODO implementar puro o no // esto qué hace?
};

/**
 * @class If
 */

class If : public Instruction, public Control_structure{
public:
	ConditionConcat* condition;
	Instruction* elseInstr;
	Instruction* child;
	Instruction* next;

	If(ConditionConcat* newCondition);
	If(ConditionConcat* newCondition, Instruction* newChild);
	If(ConditionConcat* newCondition, Instruction* newChild, Instruction* newElse);
	~If();

	MethodNodeType getMethodNodeType();
	void addChild(Instruction* newChild);
	void addElse(Instruction* nextElse);
	void print(int tabs);
	void enter_scope(Table* global);
};

/**
 * @class While
 */

class While : public Instruction, public Control_structure{
public:
	Condition* condition;

	While(Condition* newCondition);
	~While();

	MethodNodeType getMethodNodeType();
	void addChild(Instruction* newChild);
	void print(int tabs);
	void enter_scope(Table* global);
};

/**
 * @class For_init
 */

class For_init{
public:
	For_init();
	~For_init();
};

/**
 * @class For_iteration
 */

class For_iteration{
public:
	For_iteration();
	~For_iteration();
};

/**
 * @class For
 */

class For : public Instruction, public Control_structure {
public:
	For_init* for_init;
	Condition* for_condition;
	For_iteration* for_iteration;
	Instruction* child;
	Instruction* next;

	For(For_init* newFor_init, Condition* newFor_condition, For_iteration* newFor_iteration);
	~For();

	MethodNodeType getMethodNodeType();
	void addChild(Instruction* newChild);
	void print(int tabs);
	void enter_scope(Table* global);
};

/**
 * @class Return
 */

class Return : public Instruction{
public:
	Operation* return_val;

	Return(Operation* newReturn_val);
	~Return();

	MethodNodeType getMethodNodeType();
	void print(int tabs);
};

/********** Symbol Table **********/

/**
 * @class Symbol
 */

class Symbol{
	public:
		Symbol* next;
		std::string type;
		std::string identifier;

		Symbol(std::string newType, std::string newIdentifier);
		virtual ~Symbol();

		virtual void print();
		virtual void friendly_print();
		virtual SymbolType getSymbolType();
};

/**
 * @class Method_symbol
 */

class Method_symbol : public Symbol{
	public:
		Param_dec* parameter;

		Method_symbol(std::string newType, std::string newIdentifier, Param_dec* newParameter);
		~Method_symbol();
		void print();
		void friendly_print();

		SymbolType getSymbolType();
};

/**
 * @class Table
 */

class Table{
	public:
		Symbol* symbol;

		Table();
		~Table();

		void addSymbol(Symbol* newSymbol);
		Table* clone();
		virtual std::string searchInTable(std::string word);
		virtual void print();
};

/**
 * @class Method_table
 */

class Method_table : public Table{
public:
	std::string name;

	Method_table();
	Method_table(std::string newName);
	~Method_table();

	void print();
};

/********** Program **********/

/**
 * @class Program
 */

class Program{
public:
	Type* var_tree;
	Method* method_tree;

	Var_node* getDec_tree();
	Method* getMethod_tree();

	Program();
	~Program();

	void addVarDec(Type* newVar_tree);
	void addMethod(Method* newMethodTree);

	void print();
	void doSemanticAnalysis();
};
