#include "structures.h"

using namespace std;

/********** Abstract syntax tree **********/

/**
 * @class Var_node
 */

Var_node::~Var_node(){};

/**
 * @class Variable
 */

Variable::Variable(string newIdentifier) {
	identifier = newIdentifier;
	next = nullptr;
}

Variable::~Variable(){}

VarNodeType Variable::getVarNodeType(){
	return VarNodeType::Variable;
}

void Variable::addNext(Variable* newNext){
	if(next){
		Variable* it = next;
		while(it->next){
			it=it->next;
		}
		it->next = newNext;
	} else {
		next = newNext;
	}
}

void Variable::print(){
	cout << Variable::identifier << " ";
}

/**
 * @class Array
 */

Array::Array(string newIdentifier, string newSize) : Variable(newIdentifier) {
	size = newSize;
	next = nullptr;
}

Array::~Array(){}

VarNodeType Array::getVarNodeType(){
	return VarNodeType::Array;
}

void Array::print(){
	cout << identifier << "[" << size << "] ";
}

string Array::getSize(){
	return size;
}

string Array::getIdentifier(){
	return identifier;
}

/**
 * @class Method_node
 */

Method_node::~Method_node(){}

/**
 * @class Instruction.
 */

void Instruction::addNext(Instruction * newNext) {
	if(next){
		Instruction* it = next;
		while(it->next){
			it=it->next;
		}
		it->next = newNext;
	} else {
		next = newNext;
	}
}

/**
 * @class Param_dec
 */

Param_dec::Param_dec(string newType, string newValue){
	type = newType;
	value = newValue;
	next = nullptr;
}

Param_dec::~Param_dec(){}

void Param_dec::print(){
	cout << type << " " << value;
}

int Instruction::getInt(string operation) {
	int value = atoi(operation.c_str());

	if (operation.compare("0") != 0 && value == 0) { //No es int
		value = -1;
	}
	
	return value;
}

/**
 * @class Method
 */

Method::Method(string newType, string newIdentifier){
	type = newType;
	identifier = newIdentifier;
	parameter = nullptr;
	instruction = nullptr;
	next = nullptr;
}

Method::~Method(){
	Param_dec* itParam = parameter;
	while(itParam){
		Param_dec* temp = itParam;
		itParam = itParam->next;
		delete temp;
	}
	Instruction* itInstr = instruction;
	while(itInstr){
		Instruction* temp = itInstr;
		itInstr = itInstr->next;
		delete temp;
	}
}

void Method::enter_scope(Table* global){

	Table* table = global->clone();

	if(table) {
		Instruction* it = instruction;
		Type* it_type;

		Param_dec* it_p = parameter;
		while(it_p){
			global->addSymbol(new Symbol(it_p->type, it_p->value));
			it_p = it_p->next;
		}
		
		 while(it) {
	 	 	it_type = dynamic_cast<Type*>(it);
	 	 	if(it_type) {
	 	 		Variable* child = it_type->child;
		 		while(child){
	 	 			table->addSymbol(new Symbol(it_type->getType(), child->identifier));
	 	 			child = child->next;
	 	 		}
	 	 	} else {
	 	 		Control_structure* it_control = dynamic_cast<Control_structure*>(it);
	 	 		if(it_control) {
	 	 			it_control->enter_scope(global);
	 	 		} else {
					switch(it->getMethodNodeType())
					{
						case MethodNodeType::Return:{
							cout << "Return de " << identifier << endl;
							Return* it_return = dynamic_cast<Return*>(it);
							int value = it_return->getInt(it_return->return_val->getOperation());
							if(value == -1) {
								if(type.compare(table->searchInTable(it_return->return_val->getOperation())) == 0) {
									cout << "Return value del mismo tipo" << endl;
								} else {
									cout << "Tipo de retorno de metodo y  return value de tipos incompatibles" << endl;
								}
							} else {
								if(type.compare("int") == 0){
									cout << "Return value del mismo tipo" << endl;
								} else {
									cout << "Tipo de retorno de metodo y  return value de tipos incompatibles" << endl;
								}
							}
							break;
						}
						case MethodNodeType::Assignation:{
							cout << "Asignacion de " << identifier << endl;
							/*Return* it_return = dynamic_cast<Return*>(it);
							int value = it_return->getInt(it_return->return_val->getOperation());
							if(value == -1) {
								if(type.compare(table->searchInTable(it_return->return_val->getOperation())) == 0) {
									cout << "Return value del mismo tipo" << endl;
								} else {
									cout << "Tipo de retorno de metodo y  return value de tipos incompatibles" << endl;
								}
							} else {
								if(type.compare("int") == 0){
									cout << "Return value del mismo tipo" << endl;
								} else {
									cout << "Tipo de retorno de metodo y  return value de tipos incompatibles" << endl;
								}
							}*/
							break;
						}
						default:
						break;
					}
					
					Assignation* assign = dynamic_cast<Assignation*>(it);
					if(assign) {
	 	 				table->addSymbol(new Symbol("", assign->left_side));
	 	 			}else{
	 	 				// TODO analizar
						
						//analisis condiciones					
	 	 			}
				}
	 	 	}
	 	 	it = it->next;
		}
		//table->print();
	}
}

void Method::addInstruction(Instruction* newInstruction){
	if(instruction){
		Instruction* it = instruction;
		while(it->next){
			it=it->next;
		}
		it->next = newInstruction;
	} else {
		instruction = newInstruction;
	}
}

void Method::addParam(Param_dec* newParameter) {
	if(parameter){
		Param_dec* it = parameter;
		while(it->next){
			it=it->next;
		}
		it->next = newParameter;
	} else {
		parameter = newParameter;
	}
}

void Method::print(int tabs){
	cout << type << " " << identifier << endl;
	Instruction* itInstr = instruction;
	while(itInstr){
		MethodNodeType methodNodeType = itInstr->getMethodNodeType();
		switch (methodNodeType) {
			default:
				break;
			case MethodNodeType::Declaration:{
				Type* itDec = dynamic_cast<Type*>(itInstr);
				itDec->print(1);
				break;
			}
			case MethodNodeType::Assignation:{
				Assignation* itAssign = dynamic_cast<Assignation*>(itInstr);
				itAssign->print(1);
				break;
			}
			case MethodNodeType::Method_call:{
				Method_call* itMethod_c = dynamic_cast<Method_call*>(itInstr);
				itMethod_c->print(1);
				break;
			}
			case MethodNodeType::Print:{
				Print* itPrint = dynamic_cast<Print*>(itInstr);
				itPrint->print(1);
				break;
			}
			case MethodNodeType::Input:{
				Input* itInput = dynamic_cast<Input*>(itInstr);
				itInput->print(1);
				break;
			}
			case MethodNodeType::If:{
				If* itIf = dynamic_cast<If*>(itInstr);
				itIf->print(1);
				break;
			}
			case MethodNodeType::While:{
				While* itWhile = dynamic_cast<While*>(itInstr);
				itWhile->print(1);
				break;
			}
			case MethodNodeType::For: {
				For* itFor = dynamic_cast<For*>(itInstr);
				itFor->print(1);
				break;
				}
			case MethodNodeType::Return:{
				Return* itRet = dynamic_cast<Return*>(itInstr);
				itRet->print(1);
				break;
			}
		}
		itInstr=itInstr->next;
	}
}

/**
 * @class Type
 */

Type::Type(string newType) {
	type = newType;
	child = nullptr;
	next = nullptr;
}

Type::~Type() {
	Variable* it = child;
	while(it){
		Variable* temp = it;
		it = temp->next;
		delete temp;
	}
}

void Type::addVariable(Variable* newChild){
	if(child){
		Variable* it = child;
		while(it->next){
			it=it->next;
		}
		it->next = newChild;
	} else {
		child = newChild;
	}
}

string Type::getType() {
	return type;
}

VarNodeType Type::getVarNodeType(){
	return VarNodeType::Type;
}

MethodNodeType Type::getMethodNodeType(){
	return MethodNodeType::Declaration;
}

void Type::print(){
	cout << type << " ";
	Variable* it = child;
	while(it){
		VarNodeType varNodeType = it->getVarNodeType();
		switch (varNodeType) {
			default:
				break;
			case VarNodeType::Variable:{
				it->print();
				break;
			}
			case VarNodeType::Array:{
				Array *arrit = dynamic_cast<Array*>(it);
				arrit->print();
				break;
			}
		}
		it=it->next;
	}
	cout << endl;
}

void Type::print(int tabs){
	for(int i = 0; i < tabs; ++i) {
		cout << "\t";
	}
	cout << type << " ";

	Variable* it = child;
	while(it){
		VarNodeType varNodeType = it->getVarNodeType();
		switch (varNodeType) {
			default:
				break;
			case VarNodeType::Variable:{
				it->print();
				break;
			}
			case VarNodeType::Array:{
				Array *arrit = dynamic_cast<Array*>(it);
				arrit->print();
				break;
			}
		}
		it=it->next;
	}
	cout << endl;
}

/**
 * @class Operation
 */

Operation::~Operation(){
	if(lOperation){
		delete lOperation;
	}
	if(rOperation){
		delete rOperation;
	}
}

void Operation::addLeftOperation(Operation* newLOperation){
	lOperation = newLOperation;
}

void Operation::addRightOperation(Operation* newROperation){
	rOperation = newROperation;
}

void Operation::print(){
	cout << getOperation();
}

SumOperation::SumOperation(Operation* newLOperation, Operation* newROperation){
	lOperation = newLOperation;
	rOperation = newROperation;
}
SumOperation::~SumOperation(){}

OperationType SumOperation::getOperationType(){
	return OperationType::Sum;
}

string SumOperation::getOperation(){
	return "Suma";
}

SubOperation::SubOperation(Operation* newLOperation, Operation* newROperation){
	lOperation = newLOperation;
	rOperation = newROperation;
}
SubOperation::~SubOperation(){}

OperationType SubOperation::getOperationType(){
	return OperationType::Sub;
}

string SubOperation::getOperation(){
	return "Resta";
}

MultOperation::MultOperation(Operation* newLOperation, Operation* newROperation){
	lOperation = newLOperation;
	rOperation = newROperation;
}

MultOperation::~MultOperation(){}

string MultOperation::getOperation(){
	return "Multiplicación";
}

OperationType MultOperation::getOperationType(){
	return OperationType::Multiplication;
}

DivOperation::DivOperation(Operation* newLOperation, Operation* newROperation){
	lOperation = newLOperation;
	rOperation = newROperation;
}

DivOperation::~DivOperation(){}

string DivOperation::getOperation(){
	return "División";
}

OperationType DivOperation::getOperationType(){
	return OperationType::Division;
}

/**
 * @class OperationTerminal
 */

OperationTerminal::OperationTerminal(){}

OperationTerminal::~OperationTerminal(){}

void OperationTerminal::print(){}
 	
TerminalOperationType OperationTerminal::getOperationTerminalType(){
	return operationTerminalType;
}

string OperationTerminal::getOperation(){return "";}

OperationType OperationTerminal::getOperationType(){return OperationType::Terminal;}

/*****/

SimpleOperationTerminal::SimpleOperationTerminal(TerminalOperationType newOperationTerminalType, std::string newValue){
	operationTerminalType = newOperationTerminalType;
	value = newValue;
}
 
SimpleOperationTerminal::~SimpleOperationTerminal(){}

void SimpleOperationTerminal::print(){}

OperationType SimpleOperationTerminal::getOperationType(){return OperationType::Terminal;}

string SimpleOperationTerminal::getOperation(){return value;}
/*******/

MethodCallOperationTerminal::MethodCallOperationTerminal(TerminalOperationType newOperationTerminalType, Method_call* newMethod_call){
	operationTerminalType = newOperationTerminalType;
	method_call = newMethod_call;
}

MethodCallOperationTerminal::~MethodCallOperationTerminal(){}

void MethodCallOperationTerminal::print(){}

OperationType MethodCallOperationTerminal::getOperationType(){return OperationType::Terminal;}

string MethodCallOperationTerminal::getOperation(){return method_call->instructionToString();}

CastOperationTerminal::CastOperationTerminal(TerminalOperationType newOperationTerminalType, Cast* newCast){
	operationTerminalType = newOperationTerminalType;
	cast = newCast;
}

CastOperationTerminal::~CastOperationTerminal(){}

void CastOperationTerminal::print(){}

OperationType CastOperationTerminal::getOperationType(){return OperationType::Terminal;}

string CastOperationTerminal::getOperation(){return "";}

/**
 * @class assignation
 */

Assignation::Assignation(std::string newLeft_side, std::string newAssignOperator, std::string newRightSide){
	left_side = newLeft_side;
	assign_operator = newAssignOperator;
	right_side = newRightSide;
	next = nullptr;
}

Assignation::~Assignation(){}

MethodNodeType Assignation::getMethodNodeType(){
	return MethodNodeType::Assignation;
}

string Assignation::instructionToString(){
	string str_cat;
	str_cat.append(left_side);
	str_cat.append(assign_operator);
	str_cat.append(right_side);

	return str_cat;
}

void Assignation::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << left_side << " " << assign_operator << " " << right_side << endl;
}

/**
 * @class Param_dec
 */

Parameter::Parameter(string newValue){
	value = newValue;
	next = nullptr;
}

Parameter::~Parameter(){}

void Parameter::addNext(Parameter* newNext) {
	if(next){
		Parameter* it = next;
		while(it->next){
			it=it->next;
		}
		it->next = newNext;
	} else {
		next = newNext;
	}
}

string Parameter::getValue() {
	return value;
}

/**
 * @class Method_call
 */

Method_call::Method_call(string newIdentifier) {
	identifier = newIdentifier;
	child = nullptr;
	next = nullptr;
}

Method_call::~Method_call(){}

void Method_call::addParameter(Parameter* newChild) {
	if(child){
		Parameter* it = child;
		while(it->next){
			it=it->next;
		}
		it->next = newChild;
	} else {
		child = newChild;
	}
}

MethodNodeType Method_call::getMethodNodeType() {
	return MethodNodeType::Method_call;
}

string Method_call::instructionToString() {
	string string_method= "";
	if (child) {
		string_method.append(identifier);
		string_method.append("(");
		Parameter* it = child;
		while(it->next){
			string_method.append(it->getValue());
			string_method.append(",");
			it=it->next;
		}
		string_method.append(it->getValue());
		string_method.append(")");
	}
	return string_method;
}

void Method_call::print(int tabs) {}

/**
 * @class Cast
 */

Cast::Cast(string newType, InputValue* newInput) {
	type = newType;
	input = newInput;
}

Cast::~Cast(){}

string Cast::instructionToString() {
	string string_cast;

	string_cast.append(type);
	string_cast.append("(");
	string_cast.append(""); //ARREGLAR
	string_cast.append(")");

	return string_cast;
}

void Cast::print() {
	cout << instructionToString() << endl;
}

/**
 * @class Concat
 */

Concat::Concat(string newStringMsg){
	stringMsg = newStringMsg;
}

Concat::~Concat(){}

void Concat::addNext(Concat * newNext) {
	if(next){
		Concat* it = next;
		while(it->next){
			it=it->next;
		}
		it->next = newNext;
	} else {
		next = newNext;
	}
}

string Concat::getConcatMsg() {
		string string_concat= "";
	if (next) {
		string_concat.append(next->stringMsg);
		Concat* it = next;
		while(it->next){
			string_concat.append("+");
			string_concat.append(it->stringMsg);
			it=it->next;
		}
		string_concat.append("+");
		string_concat.append(it->stringMsg);
	}
	return string_concat;
}

void Concat::print(){
	cout << getConcatMsg() << endl;
}

/**
 * @class Print
 */

Print::Print(){
	child = nullptr;
	next = nullptr;
}

Print::~Print(){}

void Print::addConcatenation(Concat* newChild){}

MethodNodeType Print::getMethodNodeType(){
	return MethodNodeType::Print;
}

void Print::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << "print" << endl;
	if (child){
		Concat* it = child;
		while(it){
			it->print();
			it=it->next;
		}
	}
}

/**
 * @class Input
 */

Input::Input(string newMessage){
	message = newMessage;
	next = nullptr;
}

Input::~Input(){}

MethodNodeType Input::getMethodNodeType(){
	return MethodNodeType::Input;
}

string Input::instructionToString() {
	return "Input";
}

void Input::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << "input" << " " << message << endl;
}

/**
 * @class Value
 */

Value::Value(ValueType newValueType){
	valueType = newValueType;
}
Value::~Value(){}

/**
 * @class SimpleValue
 */

SimpleValue::SimpleValue(ValueType newValueType, std::string newValue) : Value(newValueType){
	 value = newValue;
}

SimpleValue::~SimpleValue(){}

ValueType SimpleValue::getValueType(){
	return valueType;
}

void SimpleValue::print(){
	cout << value;
}

/**
 * @class OperationValue
 */

OperationValue::OperationValue(ValueType newValueType, Operation* newOperation) : Value(newValueType){
	operation = newOperation;
}

OperationValue::~OperationValue(){
	delete operation;
}

ValueType OperationValue::getValueType(){
	return valueType;
}

void OperationValue::print(){
	operation->print();
}

/**
 * @class OperationValue
 */

InputValue::InputValue(ValueType newValueType, Input* newInput) : Value(newValueType){
	input = newInput;
}

InputValue::~InputValue(){
	delete input;
}

ValueType InputValue::getValueType(){
	return valueType;
}

void InputValue::print(){
	input->print(0); // TODO pasar tabs
}

/**
 * @class Condition
 */

Condition::~Condition(){}

ConditionType Condition::getConditionType(){
	return conditionType;
}

/**
 * @class ConditionConcat
 */

ConditionConcat::ConditionConcat(ConditionType newConditionType){
	conditionType = newConditionType;
}

ConditionConcat::~ConditionConcat(){
	if(lCondition){
		delete lCondition;
	}
	if(rCondition){
		delete rCondition;
	}
}

void ConditionConcat::addLeftCondition(Condition* newLCondition){
	lCondition = newLCondition;
}

void ConditionConcat::addRightCondition(Condition* newRCondition){
	rCondition = newRCondition;
}

void ConditionConcat::print(){
	if(lCondition) {
		lCondition->print();
	} else {
		cout << "Left empty" << endl;
	}
	if(rCondition) {
		switch (conditionType) {
			case ConditionType::AND:{
				cout << " AND ";
				break;
			}
			case ConditionType::OR:{
				cout << " OR ";
				break;
			}
			default:
				break;
		}
		rCondition->print();
	} else {
		cout << "Right empty" << endl;
	}
}

string ConditionConcat::getTerminal(){
	return "";
}

/**
 * @class ComparisonCondition
 */

ComparisonCondition::ComparisonCondition(ConditionType newConditionType, bool isNegatedP){
	conditionType = newConditionType;
	isNegated = isNegatedP;
}

ComparisonCondition::~ComparisonCondition(){
	if(lCondition){
		delete lCondition;
	}
	if(rCondition){
		delete rCondition;
	}
}

void ComparisonCondition::addLeftCondition(Condition* newLCondition){
	lCondition = newLCondition;
}

void ComparisonCondition::addRightCondition(Condition* newRCondition){
	rCondition = newRCondition;
}

void ComparisonCondition::print(){
	if(lCondition){
		lCondition->print();
	} else {
		cout << "Left de comp vacio" << endl;
	}
	if(rCondition){
		switch (conditionType) {
			case ConditionType::EQ:{
				cout << " == ";
				break;
			}
			case ConditionType::NEQ:{
				cout << " != ";
				break;
			}
			case ConditionType::LESS:{
				cout << " < ";
				break;
			}
			case ConditionType::LESSEQ:{
				cout << " <= ";
				break;
			}
			case ConditionType::GREATER:{
				cout << " > ";
				break;
			}
			case ConditionType::GREATEQ:{
				cout << " >= ";
				break;
			}
			default:
				break;
		}
		rCondition->print();
	} else {
		cout << "r vacio" << endl;
	}
}

string ComparisonCondition::getTerminal(){
	return "";
}

/**
 * @class TerminalCondition
 */

TerminalCondition::TerminalCondition(Operation* newOperation){
	operation = newOperation;
}

ConditionType TerminalCondition::getOperationType(){
	return conditionType;
}

void TerminalCondition::print(){
	operation->print();
}

string TerminalCondition::getTerminal(){
	return operation->getOperation(); // ??
}

/**
 * @class If
 */

 If::If(ConditionConcat* newCondition) {
 		condition = newCondition;
 		child = nullptr;
 		elseInstr = nullptr;
 }

 If::If(ConditionConcat* newCondition, Instruction* newChild) {
 		condition = newCondition;
 		child = newChild;
 		elseInstr = nullptr;
 }

If::If(ConditionConcat* newCondition, Instruction* newChild, Instruction* newElse) {
		condition = newCondition;
		child = newChild;
		elseInstr = newElse;
}

If::~If(){
	delete condition;
	if(elseInstr){
		delete elseInstr;
	}
	if(child){
		delete child;
	}
}

MethodNodeType If::getMethodNodeType(){
	return MethodNodeType::If;
}

void If::addChild(Instruction* newChild){
		if(child){
		Instruction* it = next;
		while(it->next){
			it=it->next;
		}
		it->next = newChild;
	} else {
		next = newChild;
	}
}

// Esta implementación no tiene sentido, un if solo puede tener un else

// void If::addElse(Instruction* nextElse) {
// 	if(elseInstr){
// 		Instruction* it = elseInstr;
// 		while(it->next){
// 			it=it->next;
// 		}
// 		it->next = nextElse;
// 	} else {
// 		next = nextElse;
// 	}
// }

void If::addElse(Instruction* nextElse) {
	elseInstr = nextElse;
}

void If::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << "if(";
	if(condition) {
		condition->print();
	}
	cout << ")" << endl;
		if (child){
		Instruction* it = child;
		while(it){
			it->print(tabs+1);
			it=it->next;
		}
	}

	if(elseInstr){
		for(int i = 0; i < tabs; ++i){
		cout << "\t";
		}
		cout << "else" << endl;
		if(elseInstr){
			Instruction* it = elseInstr;
			while(it){
				it->print(tabs+1);
				it=it->next;
			}
		}
	}
}

void If::enter_scope(Table* global) {
	Table* table = global->clone();
	string word; //Operacion a parsear o analizar
	int value; //Guardar valor si es un int
	int short cont = 0;
	string type;
	
	ComparisonCondition* it = dynamic_cast<ComparisonCondition*>(condition->lCondition);
		
	while(cont <= 1 && it){
		type = table->searchInTable(it->lCondition->getTerminal());
			
		if (type.compare("") != 0) { //Verifica variable este en tabla
			word = it->rCondition->getTerminal();
			
			value = atoi(word.c_str());

			if (word.compare("0") != 0 && value == 0) { //No es int
				if(type.compare(table->searchInTable(word).c_str()) == 0) {
					cout << "Mismo tipo" << endl;
				}
			} else { //Es int
				if(type.compare("int") == 0) {
					cout << "Mismo tipo int" << endl;
				} else {
					cout << "Tipos incompatibles" << endl;
				}
			} 
		} else {
			cout << "Variable no declarada" << endl;
		}
		it = dynamic_cast<ComparisonCondition*>(condition->rCondition);
		++cont;
	}

	if(table) {
		Instruction* it_instruction = child;
		Type* it_type;

			while(it_instruction) {
		 		it_type = dynamic_cast<Type*>(it_instruction); //Verifica si es una declaracion de variable
		 		if(it_type) {
		 			Variable* child = it_type->child;

					while(child->next){ //Mientras haya variables de lista
		 				table->addSymbol(new Symbol(it_type->getType(), child->identifier));
		 				child = child->next;
		 			}
		 			table->addSymbol(new Symbol(it_type->getType(), child->identifier));
		 		} else {
					 Control_structure* it_control = dynamic_cast<Control_structure*>(it_instruction);
	 	 			if(it_control) {
	 	 				it_control->enter_scope(global);
	 	 			} else {
						switch(it_instruction->getMethodNodeType()){
							case MethodNodeType::Assignation:{
								cout << "Asignacion de IF " << endl;
								/*Assignation* assign = dynamic_cast<Assignation*>(it);
								word = table->searchInTable(assign->left_side)
								if(word.compare("") != 0) { //Esta en la tabla
									//FALTA PORQUE NO SE PUEDE COMPRAR CON VALUE QUE ES UN STRING
								} else {
									cout << "Variable no declarada" << endl;
								}*/
								break;
							}
							default:
							break;
						}
	 	 				// TODO analizar
						
						//analisis condiciones
						
	 	 			}
		 		}
		 		it_instruction = it_instruction->next;
		 	}
			
			
			//cout << "TABLA IF" <<endl;
			//table->print();
	}
}

/**
 * @class While
 */

While::While(Condition* newCondition){
		condition = newCondition;
}

While::~While(){}

MethodNodeType While::getMethodNodeType(){
	return MethodNodeType::While;
}

void While::print(int tabs){
	cout << "while block" << endl;
	// TODO
}

void While::enter_scope(Table* global){
	// TODO
}

/**
 * @class For_init
 */

For_init::For_init(){}

For_init::~For_init(){}

/**
 * @class For_iteration
 */

For_iteration::For_iteration(){}

For_iteration::~For_iteration(){}

/**
 * @class For
 */

For::For(For_init* newFor_init, Condition* newFor_condition, For_iteration* newFor_iteration){
		for_init = newFor_init;
		for_condition = newFor_condition;
		for_iteration = newFor_iteration;
}

For::~For(){}

MethodNodeType For::getMethodNodeType(){
	return MethodNodeType::For;
}

void For::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << "for block" << endl;
	if (child){
		Instruction* it = child;
		while(it){
			it->print(tabs+1);
			it=it->next;
		}
	}
}

void For::enter_scope(Table* global){}

/**
 * @class Return
 */

Return::Return(Operation* newReturn_val){
	return_val = newReturn_val;
}

Return::~Return(){}

MethodNodeType Return::getMethodNodeType(){
	return MethodNodeType::Return;
}

void Return::print(int tabs){
	for(int i = 0; i < tabs; ++i){
		cout << "\t";
	}
	cout << "return ";
	if (return_val){
		return_val->print();
	}
}

/********** Symbol Table **********/

/**
 * @class Symbol
 */

Symbol::Symbol(string newType, std::string newIdentifier){
	type = newType;
	identifier = newIdentifier;
}

Symbol::~Symbol(){}

// Implementación correcta
void Symbol::print(){
	 cout << "Variable: " << type << " " << identifier << endl;
 }

// void Symbol::print(){
// 	friendly_print();
// 	Symbol* it = next; // El símbolo no tiene que iterar, todo se hace desde arriba!
//
// 	while(it) {
// 		it->friendly_print();
// 		it = it->next;
// 	}
// }

void Symbol::friendly_print(){
	cout << "Variable: " << type << " " << identifier << endl;
}

SymbolType Symbol::getSymbolType(){
	return SymbolType::Variable;
}

/**
 * @class Method_symbol
 */

Method_symbol::Method_symbol(std::string newType, std::string newIdentifier, Param_dec* newParameter):Symbol(newType, newIdentifier){
	parameter = newParameter;
}

Method_symbol::~Method_symbol(){}

// Implementación adecuada
void Method_symbol::print(){
	cout << "Method: " << type << " " << identifier << "(";
	if(parameter) {
		parameter->print();
	}
	cout << ")" << endl;
}

// void Method_symbol::print(){
// 	friendly_print();
// 	Symbol* it = next;
//
// 	while(it) {
// 		it->friendly_print();
// 		it = it->next;
// 	}
// }

void Method_symbol::friendly_print(){
	cout << "Method: " << type << " " << identifier << "(";
	if(parameter) {
		parameter->print();
	}
	cout << ")" << endl;
}

SymbolType Method_symbol::getSymbolType(){
	return SymbolType::Method;
}

/**
 * @class Table
 */

Table::Table(){}

Table::~Table(){
	Symbol* it = symbol;
	while(symbol){
		Symbol* temp = it;
		it = it->next;
		delete temp;
	}
}

void Table::addSymbol(Symbol* newSymbol){
	if(symbol){
		Symbol* it = symbol;
		while(it->next){
			it=it->next;
		}
		it->next = newSymbol;
	} else {
		symbol = newSymbol;
	}
}

Table* Table::clone(){
	Table* newTable = new Table();

	Symbol* it = symbol;
	while(it){
		switch (it->getSymbolType()) {
			case SymbolType::Variable:{
				Symbol* temp = new Symbol(it->type, it->identifier);
				newTable->addSymbol(temp);
				break;
			}
			case SymbolType::Method:{
				Method_symbol* itMethod = dynamic_cast<Method_symbol*>(it);
				Method_symbol* temp = new Method_symbol(itMethod->type, itMethod->identifier, itMethod->parameter);
				newTable->addSymbol(temp);
				break;
			}
			default:
				break;
		}
	it = it->next;
	}
	return newTable;
}

void Table::print(){
	cout << endl << "******************************" << endl << endl << "Symbol table" << endl << endl;
	cout << "______________________________" << endl;
	// cout << "Global" << endl;
	cout << "------------------------------" << endl;
	Symbol* it = symbol;
	while(it){
		it->print();
		it = it->next;
	}
	cout << "______________________________" << endl << endl;
}

string Table::searchInTable(string word){
	cout << "Word: " << word << endl; 

	string exit = "";
	Symbol* it = symbol;
	
	while(it && exit == ""){
		if (word.compare(it->identifier) == 0) {
			exit = it->type;
		}
		it = it->next;
	}
	 
	return exit;
}

/**
 * @class Method_table
 */

Method_table::Method_table(std::string newName){
	name = newName;
}

Method_table::~Method_table(){}

void Method_table::print(){}

/********** Program **********/

/**
 * @class Program
 */

Program::Program(){}

Program::~Program(){
	Instruction* itVar = var_tree;
	while(itVar){
		Type* temp = dynamic_cast<Type*>(itVar);
		itVar=itVar->next;
		delete temp;
	}

	Method* itMethod = method_tree;
	while(itMethod){
		Method* temp = dynamic_cast<Method*>(itMethod);
		itMethod=itMethod->next;
		delete temp;
	}
}

void Program::addVarDec(Type* newVar){
	if(var_tree){
		Instruction* itType = var_tree;
		while(itType->next){
			itType=itType->next;
		}
		itType->next = newVar;
	} else {
		var_tree = newVar;
	}
}

void Program::addMethod(Method* newMethod) {
	if(method_tree){
		Method* itMethod = method_tree;
		while(itMethod->next){
			itMethod=itMethod->next;
		}
		itMethod->next = newMethod;
	} else {
		method_tree = newMethod;
	}
}

void Program::print(){
	// Variable declaration tree
	Instruction* it = var_tree;
	Type* itType;

	while(it){
		itType = dynamic_cast<Type*>(it);
		itType->print();
		it=it->next;
	}

	//Method tree
	Method* itMethod = method_tree;

	while(itMethod){
		itMethod->print(0);
		itMethod=itMethod->next;
	}
}

void doSemanticAnalysis() {
	/* TODO */
}
