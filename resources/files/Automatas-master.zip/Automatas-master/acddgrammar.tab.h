/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_ACDDGRAMMAR_TAB_H_INCLUDED
# define YY_YY_ACDDGRAMMAR_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    TASSIGN = 258,
    TLESS = 259,
    TLESSEQ = 260,
    TGREATER = 261,
    TGREATEREQ = 262,
    TEQUAL = 263,
    TNOTEQUAL = 264,
    TNEGATION = 265,
    TPLUS = 266,
    TMINUS = 267,
    TMUL = 268,
    TDIV = 269,
    TMOD = 270,
    TPLUSEQ = 271,
    TMINUSEQ = 272,
    TMULEQ = 273,
    TDIVEQ = 274,
    TMODEQ = 275,
    TAND = 276,
    TOR = 277,
    TOPENPAREN = 278,
    TCLOSEPAREN = 279,
    TOPENSQRBRACK = 280,
    TCLOSESQRBRACK = 281,
    TCOMMA = 282,
    TCOLON = 283,
    TBOOL = 284,
    TCHAR = 285,
    TCHARWORD = 286,
    TDOUBLE = 287,
    TELSE = 288,
    TFALSE = 289,
    TFLOAT = 290,
    TFOR = 291,
    TIF = 292,
    TINPUT = 293,
    TINT = 294,
    TLONG = 295,
    TNULL = 296,
    TRETURN = 297,
    TSTRINGWORD = 298,
    TTRUE = 299,
    TUNSIGNED = 300,
    TVOID = 301,
    TWHILE = 302,
    TIDENTIFIER = 303,
    TSTRING = 304,
    TLINEBREAK = 305,
    TEND = 306,
    TMAIN = 307,
    TPRINT = 308,
    TINTNUM = 309,
    TFLOATNUM = 310,
    ERROR = 311,
    OP = 312,
    INCDEC = 313,
    UMINUS = 314
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 70 "acddgrammar.y" /* yacc.c:1909  */

	char* operat;
	char* misc;
	char* word;
	int intval;
	float floatval;
	char* error;
	char* production;
	Var_node* var_node;
	Variable* variable;
	Instruction* instruction;
	Method_call* mth_call;
	Parameter* mth_call_param;
	While* w;
	For* f;
	Print* print;
	Method* method;
	Method_node* method_node;
	If* i;
	Concat* concat;
	Operation* operation;
	Param_dec* parDec;
	Type* t;
	ConditionConcat* cond;
	Cast* casting;
	Value* val;

#line 142 "acddgrammar.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_ACDDGRAMMAR_TAB_H_INCLUDED  */
