#Pendiente

## Diego

* Reemplazar todos los tipos de operaciones por un único tipo de operación aritmética que los contenga a todos.
* Operation terminal puede ser una variable o un número (caso simple), pero también puede ser llamado a método y casteo (caso complejo). Resolver implementación.
  * Posible solución: class SimpleOperationTerminal, class MethodCallOperationTerminal y class CastOperationTerminal.
* Caso similar al anterior con value.
  * Posible solución: class SimpleValue, class OperationValue y class CastValue.
* Implementar las clases que heredan de value.

# Hecho

* Declaración de Value y clases derivadas.
* Mejorada la implementación de Condition.